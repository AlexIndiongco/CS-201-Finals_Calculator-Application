// Indiongco, Alex Andhrei P.   |   CS-201
//Set A: Calculator

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class calculator extends JFrame implements ActionListener {
    static JFrame f;
    static JTextField l;
    String s0, s1, s2;

    calculator(){
        s0 = s1 = s2 = "";
    }

    public static void main(String[] args) {
        f = new JFrame("Simple Calculator");

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        }

        catch (Exception e) {
            System.err.println(e.getMessage());
        }

        calculator c = new calculator();
        l = new JTextField(20);
        l.setEditable(false);
        JButton b0, b1, b2, b3, b4, b5, b6, b7, b8, b9, bAdd, bSub, bDiv, bMult, bDot, bEq, bEq1, bExit;

        b0 = new JButton("0");
        b1 = new JButton("1");
        b2 = new JButton("2");
        b3 = new JButton("3");
        b4 = new JButton("4");
        b5 = new JButton("5");
        b6 = new JButton("6");
        b7 = new JButton("7");
        b8 = new JButton("8");
        b9 = new JButton("9");

        bAdd = new JButton("+");
        bSub = new JButton("-");
        bDiv = new JButton("/");
        bMult = new JButton("*");
        bEq = new JButton("C");
        bEq1 = new JButton("=");
        bDot = new JButton(".");
        bExit = new JButton("Exit");
        
    
        JPanel panel = new JPanel();
        
        // ActionListener Operators
        bMult.addActionListener(c);
        bDiv.addActionListener(c);
        bSub.addActionListener(c);
        bAdd.addActionListener(c);
        bDot.addActionListener(c);
        bEq.addActionListener(c);
        bEq1.addActionListener(c);
        bExit.addActionListener(c);
        
        // ActionListen Nums
        b9.addActionListener(c);
        b8.addActionListener(c);
        b7.addActionListener(c);
        b6.addActionListener(c);
        b5.addActionListener(c);
        b4.addActionListener(c);
        b3.addActionListener(c);
        b2.addActionListener(c);
        b1.addActionListener(c);
        b0.addActionListener(c);
        
        
        // Button Panel
        panel.add(l);
        panel.add(b7);
        panel.add(b8);
        panel.add(b9);
        panel.add(bAdd);

        panel.add(b4);
        panel.add(b5);
        panel.add(b6);
        panel.add(bSub);

        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(bMult);

        panel.add(b0);
        panel.add(bDot);
        panel.add(bEq);
        panel.add(bDiv);

        panel.add(bEq1);
        panel.add(bExit);

        panel.setBackground(Color.white);
        f.add(panel);
        f.setSize(200, 220);
        f.show();
    }

    public void actionPerformed(ActionEvent e) {
        String s = e.getActionCommand();
        

        if ((s.charAt(0) >= '0' && s.charAt(0) <= '9') || s.charAt(0) == '.') {
            if (!s1.equals(""))
                s2 = s2 + s;
            else
                s0 = s0 + s;

            l.setText(s0 + s1 + s2);
        }

        else if (s.charAt(0) == 'C') {

            s0 = s1 = s2 = "";
            l.setText(s0 + s1 + s2);
        }

        else if (s.charAt(0) == '=') {
            double te;

            if (s1.equals("+"))
                te = (Double.parseDouble(s0) + Double.parseDouble(s2));
            else if (s1.equals("-"))
                te = (Double.parseDouble(s0) - Double.parseDouble(s2));
            else if (s1.equals("/"))
                te = (Double.parseDouble(s0) / Double.parseDouble(s2));
            else
                te = (Double.parseDouble(s0) * Double.parseDouble(s2));

            l.setText(s0 + s1 + s2 + "=" + te);
            s0 = Double.toString(te);

            s1 = s2 = "";
        }

        else {

            if (s1.equals("") || s2.equals(""))
                s1 = s;

            else {
                double te;

                if (s1.equals("+"))
                    te = (Double.parseDouble(s0) + Double.parseDouble(s2));
                else if (s1.equals("-"))
                    te = (Double.parseDouble(s0) - Double.parseDouble(s2));
                else if (s1.equals("/"))
                    te = (Double.parseDouble(s0) / Double.parseDouble(s2));
                else
                    te = (Double.parseDouble(s0) * Double.parseDouble(s2));

                s0 = Double.toString(te);
                s1 = s;
                s2 = "";
            }
            l.setText(s0 + s1 + s2);
        }
    }
}